<?php include 'header.php'; include 'db_connect.php';

$conn = getConnection(); ?>

<div class="container">
    <h2 class="text-center mb-4">📉 Wastage Management</h2>

    <form action="save_wastage.php" method="POST" class="p-4 border bg-light">
        <label class="form-label">Item Name:</label>
        <input type="text" name="item_name" class="form-control mb-3" required>

        <label class="form-label">Quantity:</label>
        <input type="number" name="quantity" class="form-control mb-3" required>

        <label class="form-label">Reason:</label>
        <textarea name="reason" class="form-control mb-3" required></textarea>

        <button type="submit" class="btn btn-warning w-100">Submit</button>
    </form>
</div>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wastage Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-4">
        <h2 class="mb-4 text-center">Wastage Report (Last 30 Days)</h2>
        
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Cost</th>
                    <th>Reason</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
            <?php

 // Get the PDO connection

$query = "SELECT * FROM wastage WHERE date_recorded >= NOW() - INTERVAL 30 DAY ORDER BY date_recorded DESC";
$stmt = $conn->prepare($query);
$stmt->execute();
$wastageData = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalLoss = 0;
$index = 1;

foreach ($wastageData as $row) {
    $totalLoss += $row['cost'];
    echo "<tr>
        <td>{$index}</td>
        <td>{$row['item_name']}</td>
        <td>{$row['quantity']}</td>
        <td>$" . number_format($row['cost'], 2) . "</td>
        <td>{$row['reason']}</td>
        <td>{$row['date_recorded']}</td>
    </tr>";
    $index++;
}
?>

            </tbody>
        </table>

        <h4 class="text-end">Total Loss: <span class="text-danger">$<?php echo number_format($totalLoss, 2); ?></span></h4>
    </div>
</body>
</html>
